import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
export const admin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
export async function userFrom(req) {
  const token = (req.headers.authorization || "").replace("Bearer ", "");
  const { data } = await admin.auth.getUser(token);
  return data?.user || null;
}
