import { stripe, admin } from "./_lib.js";
export const config = { api: { bodyParser: false } };
async function raw(req) { const c = []; for await (const x of req) c.push(x); return Buffer.concat(c); }
export default async function handler(req, res) {
  let event;
  try {
    event = stripe.webhooks.constructEvent(await raw(req), req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (e) { return res.status(400).send("bad signature"); }
  const o = event.data.object;
  if (event.type === "checkout.session.completed" && o.client_reference_id) {
    await admin.from("profiles").update({ is_pro: true, stripe_customer_id: o.customer }).eq("id", o.client_reference_id);
  }
  if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
    const active = ["active", "trialing"].includes(o.status) && event.type !== "customer.subscription.deleted";
    await admin.from("profiles").update({ is_pro: active }).eq("stripe_customer_id", o.customer);
  }
  res.json({ received: true });
}
