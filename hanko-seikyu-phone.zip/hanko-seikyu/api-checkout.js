import { stripe, admin, userFrom } from "./_lib.js";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const user = await userFrom(req);
  if (!user) return res.status(401).json({ error: "ログインが必要です" });
  const price = req.body?.plan === "year" ? process.env.STRIPE_PRICE_YEAR : process.env.STRIPE_PRICE_MONTH;
  const { data: p } = await admin.from("profiles").select("stripe_customer_id").eq("id", user.id).single();
  const session = await stripe.checkout.sessions.create({
    mode: "subscription", locale: "ja",
    line_items: [{ price, quantity: 1 }],
    client_reference_id: user.id,
    ...(p?.stripe_customer_id ? { customer: p.stripe_customer_id } : { customer_email: user.email }),
    success_url: `${process.env.SITE_URL}/?paid=1`,
    cancel_url: process.env.SITE_URL,
  });
  res.json({ url: session.url });
}
