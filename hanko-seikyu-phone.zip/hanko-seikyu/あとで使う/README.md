# ハンコ請求 本番用セットアップ

## 1. Supabase（ログイン）
1. supabase.com で新規プロジェクトを作成
2. SQL Editor に `supabase.sql` を貼って実行
3. Authentication > URL Configuration の Site URL に、公開後のURLを設定
4. Project Settings > API の URL と anon key を `public/config.js` に記入
5. service_role キーは `.env` / Vercel の環境変数にのみ設定（公開しない）

## 2. Stripe（決済）
1. 商品「Pro」に月額480円・年額4,800円の価格を作り、price_ID を控える
2. 設定 > Billing > カスタマーポータル を有効化
3. 公開後、開発者 > Webhook に `https://<あなたのURL>/api/webhook` を追加し、
   イベント `checkout.session.completed` / `customer.subscription.updated` /
   `customer.subscription.deleted` を選択、署名シークレット(whsec_)を控える

## 3. Vercel（公開）
1. このフォルダをGitHubにアップし、Vercelでimport（または `npx vercel`）
2. `.env.example` の全項目を Environment Variables に登録（最初は sk_test_ でテスト）
3. デプロイ後、WebhookのURLとSupabaseのSite URLを実URLに更新

## 4. テスト
テストカード 4242 4242 4242 4242 で決済 → ヘッダーが「Pro」に変わればOK。
本番化: Stripeを本番モードに切り替え、キー・price_ID・Webhookを本番用に差し替え。
公開前に `public/legal.html` の【 】を埋めてください。
