create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  is_pro boolean not null default false,
  stripe_customer_id text
);
alter table public.profiles enable row level security;
create policy "own profile readable" on public.profiles for select using (auth.uid() = id);
-- 書き込みはサーバー(service role)のみ。ユーザー自身はProに変更できません。
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles (id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
