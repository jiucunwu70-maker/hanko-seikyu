import { stripe, admin, userFrom } from "./_lib.js";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const user = await userFrom(req);
  if (!user) return res.status(401).json({ error: "ログインが必要です" });
  const { data: p } = await admin.from("profiles").select("stripe_customer_id").eq("id", user.id).single();
  if (!p?.stripe_customer_id) return res.status(400).json({ error: "契約情報がありません" });
  const s = await stripe.billingPortal.sessions.create({ customer: p.stripe_customer_id, return_url: process.env.SITE_URL });
  res.json({ url: s.url });
}
