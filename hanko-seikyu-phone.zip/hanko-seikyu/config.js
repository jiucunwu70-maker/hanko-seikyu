// SupabaseのProject Settings > API の値を入れてください（anonキーは公開してOK）
window.CFG = { SUPABASE_URL: "", SUPABASE_ANON_KEY: "" };
